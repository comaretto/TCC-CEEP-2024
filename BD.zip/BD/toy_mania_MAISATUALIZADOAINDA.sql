-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 26/09/2024 às 23:43
-- Versão do servidor: 10.4.32-MariaDB
-- Versão do PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `toy_mania`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `tb_avaliacoes`
--

CREATE TABLE `tb_avaliacoes` (
  `id_avaliacao` int(11) NOT NULL,
  `id_produto` int(11) DEFAULT NULL,
  `nome_usuario` varchar(100) DEFAULT NULL,
  `estrelas` int(11) DEFAULT NULL CHECK (`estrelas` between 1 and 5),
  `comentario` text DEFAULT NULL,
  `data_avaliacao` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `tb_avaliacoes`
--

INSERT INTO `tb_avaliacoes` (`id_avaliacao`, `id_produto`, `nome_usuario`, `estrelas`, `comentario`, `data_avaliacao`) VALUES
(2, 7, 'Anônimo', 1, 'A', '2024-09-26 14:11:06'),
(3, 7, 'Anônimo', 5, 'A', '2024-09-26 14:12:15'),
(4, 7, 'Anônimo', 5, 'A', '2024-09-26 14:12:15'),
(5, 6, 'Anônimo', 4, 'a', '2024-09-26 14:23:36'),
(6, 6, 'Anônimo', 4, 'a', '2024-09-26 14:23:36'),
(7, 6, 'Anônimo', 5, 'a', '2024-09-26 14:25:22'),
(36, 3, 'adm', 4, 'aaaa', '2024-09-26 21:29:42');

-- --------------------------------------------------------

--
-- Estrutura para tabela `tb_carrinho`
--

CREATE TABLE `tb_carrinho` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `produto_id` int(11) NOT NULL,
  `quantidade` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `tb_categorias`
--

CREATE TABLE `tb_categorias` (
  `id_categoria` int(11) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `descricao` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `tb_categorias`
--

INSERT INTO `tb_categorias` (`id_categoria`, `nome`, `descricao`) VALUES
(1, 'Novidades', 'Produtos recentemente adicionados à loja.'),
(2, 'Lego', 'Produtos da linha Lego.'),
(3, 'Bonecas', 'Diversas bonecas e acessórios.'),
(4, 'Hot_Wheels', 'Produtos da linha Hot Wheels.'),
(5, 'Barbie', 'Produtos da linha Barbie.'),
(6, 'Jogos', 'Produtos do tipo Jogos.'),
(7, 'Lançamentos', 'Produtos da récem-lançados.'),
(8, 'Disney', 'Produtos da linha Disney.'),
(9, 'Esportes', 'Produtos esportivos.');

-- --------------------------------------------------------

--
-- Estrutura para tabela `tb_clientes`
--

CREATE TABLE `tb_clientes` (
  `id_cliente` int(11) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `senha` varchar(255) NOT NULL,
  `tipo` varchar(50) NOT NULL,
  `dt_nascimento` date NOT NULL,
  `ativo` tinyint(1) NOT NULL,
  `telefone` varchar(20) NOT NULL,
  `foto_perfil` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `tb_clientes`
--

INSERT INTO `tb_clientes` (`id_cliente`, `nome`, `email`, `senha`, `tipo`, `dt_nascimento`, `ativo`, `telefone`, `foto_perfil`) VALUES
(1, 'adm', 'adm@gmail.com', '123', 'admin', '2007-06-24', 1, '11111111111111111111', '../uploads/Colorful Pastel Playful Cute Baby Spa Logo (1).png'),
(2, 'ed', 'divinelord190@gmail.com', '123', 'cliente', '2007-06-06', 1, '', NULL),
(3, 'Gustavo Comaretto', 'gustavocomaretto@gmail.com', '123', 'cliente', '2007-12-11', 1, '1', 'uploads/Captura de Tela (48).png'),
(14, 'GUSTAVO COMARETTO', 'g@gmail.com', '123', 'cliente', '0000-00-00', 0, '11111111111', 'Icones/usuario.svg');

-- --------------------------------------------------------

--
-- Estrutura para tabela `tb_contato`
--

CREATE TABLE `tb_contato` (
  `id_mensagem` int(11) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `mensagem` text NOT NULL,
  `data_envio` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `tb_itens_compra`
--

CREATE TABLE `tb_itens_compra` (
  `id_item` int(11) NOT NULL,
  `id_compra` int(11) NOT NULL,
  `id_produto` int(11) NOT NULL,
  `data_compra` int(11) NOT NULL,
  `preco` decimal(10,2) NOT NULL,
  `quantidade` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `tb_itens_compra`
--

INSERT INTO `tb_itens_compra` (`id_item`, `id_compra`, `id_produto`, `data_compra`, `preco`, `quantidade`) VALUES
(1, 2, 4, 1, 199.99, 0),
(2, 3, 3, 1, 149.99, 0),
(3, 4, 5, 0, 349.99, 1),
(4, 5, 4, 0, 199.99, 1),
(5, 6, 4, 0, 199.99, 1),
(6, 7, 5, 0, 349.99, 1),
(7, 8, 4, 0, 199.99, 1),
(8, 8, 5, 0, 349.99, 1),
(9, 8, 3, 0, 149.99, 1),
(10, 9, 4, 0, 199.99, 1),
(11, 10, 4, 0, 199.99, 1),
(12, 11, 1, 0, 100.04, 1),
(13, 12, 4, 0, 199.99, 1),
(15, 14, 4, 0, 199.99, 2),
(16, 14, 5, 0, 349.99, 1),
(17, 15, 4, 0, 199.99, 1),
(18, 16, 3, 0, 149.99, 3),
(19, 16, 2, 0, 349.99, 6),
(20, 16, 4, 0, 199.99, 1),
(21, 16, 1, 0, 100.04, 1),
(22, 17, 2, 0, 349.99, 5),
(23, 18, 1, 0, 100.04, 1),
(24, 18, 2, 0, 349.99, 1),
(25, 19, 4, 0, 199.99, 2),
(26, 20, 4, 0, 199.99, 1),
(27, 21, 4, 0, 199.99, 1),
(30, 24, 4, 0, 199.99, 1),
(31, 25, 37, 0, 199.00, 1);

-- --------------------------------------------------------

--
-- Estrutura para tabela `tb_pedidos`
--

CREATE TABLE `tb_pedidos` (
  `id_pedido` int(11) NOT NULL,
  `id_cliente` int(11) NOT NULL,
  `data_pedido` datetime NOT NULL DEFAULT current_timestamp(),
  `total` decimal(10,2) DEFAULT NULL,
  `status` varchar(50) DEFAULT 'Pendente'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `tb_pedidos`
--

INSERT INTO `tb_pedidos` (`id_pedido`, `id_cliente`, `data_pedido`, `total`, `status`) VALUES
(1, 0, '2024-08-08 18:55:02', 199.99, 'Pendente'),
(2, 0, '2024-08-08 18:55:14', 199.99, 'Pendente'),
(3, 0, '2024-08-08 18:55:36', 149.99, 'Pendente'),
(4, 1, '2024-08-08 23:13:51', 349.99, 'Pendente'),
(5, 1, '2024-08-08 23:21:33', 199.99, 'Pendente'),
(6, 3, '2024-08-09 14:18:57', 199.99, 'Pendente'),
(7, 3, '2024-08-09 14:21:34', 349.99, 'Pendente'),
(8, 3, '2024-08-09 14:39:37', 699.97, 'Pendente'),
(9, 3, '2024-08-09 15:13:41', 199.99, 'Pendente'),
(10, 3, '2024-08-09 15:15:54', 199.99, 'Pendente'),
(11, 1, '2024-08-09 15:54:09', 100.04, 'Pendente'),
(12, 1, '2024-08-09 18:15:25', 199.99, 'Pendente'),
(13, 1, '2024-08-09 18:37:50', 119.90, 'Pendente'),
(14, 1, '2024-08-09 19:41:38', 749.97, 'Pendente'),
(15, 1, '2024-08-10 15:40:44', 199.99, 'Pendente'),
(16, 1, '2024-08-10 16:00:52', 2849.94, 'Pendente'),
(17, 1, '2024-08-10 16:16:29', 1749.95, 'Pendente'),
(18, 1, '2024-08-10 16:16:53', 450.03, 'Pendente'),
(19, 1, '2024-08-10 16:41:18', 399.98, 'Pendente'),
(20, 1, '2024-08-10 16:53:21', 199.99, 'Pendente'),
(21, 1, '2024-08-10 18:06:34', 199.99, 'Pendente'),
(24, 1, '2024-08-14 15:58:20', 199.99, 'Pendente'),
(25, 1, '2024-08-14 19:26:30', 199.00, 'Pendente');

-- --------------------------------------------------------

--
-- Estrutura para tabela `tb_produtos`
--

CREATE TABLE `tb_produtos` (
  `id_produto` int(11) NOT NULL,
  `nome` varchar(255) DEFAULT NULL,
  `categoria` varchar(255) DEFAULT NULL,
  `preco` decimal(10,2) DEFAULT NULL,
  `imagem` varchar(255) DEFAULT NULL,
  `id_categoria` int(11) DEFAULT NULL,
  `descricao` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `tb_produtos`
--

INSERT INTO `tb_produtos` (`id_produto`, `nome`, `categoria`, `preco`, `imagem`, `id_categoria`, `descricao`) VALUES
(1, 'Mochila Patrulha Canina', 'Novidades', 100.04, 'Imagens/mochila_patrulha.webp', 1, 'Mochila'),
(2, 'Pelúcia Wandinha', 'Novidades', 349.99, 'Imagens/pelucia_wandinha.webp', 3, NULL),
(3, 'Conjunto de acessórios Miniverse', 'Novidades', 149.99, 'Imagens/miniverse2.webp', 3, NULL),
(4, 'Lego Marvel Spiderman', 'Novidades', 199.99, 'Imagens/lego_spiderman.webp', 2, NULL),
(5, 'Patinete Sonic', 'Novidades', 349.99, 'Imagens/patinete.webp', 1, NULL),
(6, 'Lego Minecraft Recife de Coral', 'Lego', 69.99, 'Imagens/lego_minecraft1.webp', 2, NULL),
(7, 'Lego Minecraft a Emboscada do Creeper', 'Lego', 78.99, 'Imagens/lego_minecraft2.webp', 2, NULL),
(8, 'Lego Minecraft Pousada da Raposa', 'Lego', 153.99, 'Imagens/lego_minecraft3.webp', 2, NULL),
(9, 'Lego Marvel Spiderman', 'Lego', 78.99, 'Imagens/lego_spiderman2.webp', 2, NULL),
(10, 'Lego City Police Car', 'Lego', 74.99, 'Imagens/lego_ciry.webp', 2, NULL),
(11, 'Boneca Glo Pixies', 'Bonecas', 179.99, 'Imagens/boneca_glopixies.webp', 3, NULL),
(12, 'Boneca Maria Clara', 'Bonecas', 209.99, 'Imagens/boneca_mariaclara.webp', 3, NULL),
(13, 'Boneca Minnie Patinadora', 'Bonecas', 102.99, 'Imagens/boneca_minnie_patinadora.webp', 3, NULL),
(14, 'Boneca Barbie Sereia', 'Bonecas', 179.99, 'Imagens/boneca_barbie_sereia.webp', 3, NULL),
(15, 'Boneca Cry Babies', 'Bonecas', 256.99, 'Imagens/boneca_cry_babies.webp', 3, NULL),
(35, 'Pista do Dragão - Hot Wheels', 'Hot_Wheels', 119.00, 'Imagens/pista1.jpeg', NULL, NULL),
(36, 'Pista Tubarão - Hot Wheels', 'Hot_Wheels', 119.00, 'Imagens/pista2.jpeg', NULL, NULL),
(37, 'Pista Color-Change - Hot Wheels', 'Hot_Wheels', 199.00, 'Imagens/pista3.jpeg', NULL, NULL),
(38, 'Pista Monster Truck - Hot Wheels', 'Hot_Wheels', 209.00, 'Imagens/pista4.jpeg', NULL, NULL),
(39, 'Pista Campeonato de Corridas - Hot Wheels', 'Hot_Wheels', 119.00, 'Imagens/pista5.jpeg', NULL, NULL);

-- --------------------------------------------------------

--
-- Estrutura para tabela `tb_suporte`
--

CREATE TABLE `tb_suporte` (
  `id_suporte` int(11) NOT NULL,
  `id_cliente` int(11) NOT NULL,
  `mensagem` text NOT NULL,
  `data_envio` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `tb_suporte`
--

INSERT INTO `tb_suporte` (`id_suporte`, `id_cliente`, `mensagem`, `data_envio`) VALUES
(1, 1, 'a', '2024-08-10 20:16:51'),
(2, 1, 'a', '2024-08-10 20:16:54'),
(3, 1, 'a', '2024-08-10 20:18:05'),
(4, 1, 'a', '2024-08-10 20:18:32'),
(5, 1, 'a', '2024-08-10 20:20:51'),
(6, 1, 'alo', '2024-08-10 23:46:37'),
(7, 3, 'SOCORRO', '2024-08-10 23:48:32'),
(8, 3, 'SOCORRO', '2024-08-10 23:49:01'),
(9, 3, 'SOCORRO', '2024-08-10 23:49:05'),
(10, 3, 'SOCORRO', '2024-08-10 23:49:38'),
(11, 3, 'SOCORRO', '2024-08-10 23:49:42'),
(12, 1, 'teste', '2024-08-11 00:52:10'),
(13, 1, '<?php\r\nsession_start();\r\nif (empty($_SESSION)) {\r\n    echo \"<script>location.href=\'../login.php\';</script>\";\r\n}\r\nif ($_SESSION[\"tipo\"] && $_SESSION[\"tipo\"] != \"admin\") {\r\n    echo \"Não autorizado.\";\r\n    return;\r\n}\r\n\r\ninclude_once (\'../PHP/conexao.php\');\r\n\r\n$updateMessage = \"\";\r\n\r\nif (isset($_GET[\'id\'])) {\r\n    $id = $_GET[\'id\'];\r\n    $sql = \"SELECT * FROM tb_clientes WHERE id_cliente = $id\";\r\n    $result = $conn->query($sql);\r\n\r\n    if ($result->num_rows > 0) {\r\n        $user_data = $result->fetch_assoc();\r\n    } else {\r\n        echo \"Cliente não encontrado.\";\r\n        exit;\r\n    }\r\n}\r\n\r\nif ($_SERVER[\"REQUEST_METHOD\"] == \"POST\") {\r\n    $nome = $_POST[\'nome\'];\r\n    $email = $_POST[\'email\'];\r\n    $senha = $_POST[\'senha\'];\r\n    $dt_nascimento = $_POST[\'dt_nascimento\'];\r\n    $ativo = isset($_POST[\'ativo\']) ? 1 : 0;\r\n    $tipo = $_POST[\'tipo\'];\r\n\r\n    $sql = \"UPDATE tb_clientes SET nome=\'$nome\', email=\'$email\', senha=\'$senha\', dt_nascimento=\'$dt_nascimento\', ativo=\'$ativo\', tipo=\'$tipo\' WHERE id_cliente=$id\";\r\n\r\n    if ($conn->query($sql) === TRUE) {\r\n        $updateMessage = \"Registro atualizado com sucesso\";\r\n    } else {\r\n        $updateMessage = \"Erro ao atualizar registro: \" . $conn->error;\r\n    }\r\n}\r\n?>\r\n\r\n<!DOCTYPE html>\r\n<html>\r\n\r\n<head>\r\n    <meta charset=\"utf-8\">\r\n    <meta name=\"viewport\" content=\"width=device-width\">\r\n    <title>Editar Cliente</title>\r\n    <link href=\"../style.css\" rel=\"stylesheet\" type=\"text/css\" />\r\n    <link rel=\"preconnect\" href=\"https://fonts.googleapis.com\">\r\n    <link rel=\"preconnect\" href=\"https://fonts.gstatic.com\" crossorigin>\r\n    <link\r\n        href=\"https://fonts.googleapis.com/css2?family=Braah+One&family=Work+Sans:ital,wght@0,100..900;1,100..900&display=swap\"\r\n        rel=\"stylesheet\">\r\n    <style>\r\n        .form-container {\r\n            max-width: fit-content;\r\n            margin: 20px auto;\r\n            background-color: #fff;\r\n            padding: 20px;\r\n            border-radius: 10px;\r\n            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);\r\n            position: relative; /* Adicionado para posicionar o botão de voltar dentro */\r\n        }\r\n\r\n        .form-container h2 {\r\n            text-align: center;\r\n            margin-bottom: 20px;\r\n        }\r\n\r\n        .form-container form {\r\n            display: flex;\r\n            flex-direction: column;\r\n        }\r\n\r\n        .form-container label {\r\n            margin-bottom: 5px;\r\n        }\r\n\r\n        .form-container input[type=\"text\"],\r\n        .form-container input[type=\"email\"],\r\n        .form-container input[type=\"password\"],\r\n        .form-container input[type=\"date\"],\r\n        .form-container input[type=\"number\"],\r\n        .form-container input[type=\"url\"] {\r\n            padding: 10px;\r\n            margin-bottom: 15px;\r\n            border: 1px solid #ccc;\r\n            border-radius: 5px;\r\n        }\r\n\r\n        .form-container input[type=\"checkbox\"] {\r\n            margin-bottom: 15px;\r\n        }\r\n\r\n        .form-container input[type=\"submit\"] {\r\n            padding: 10px 15px;\r\n            border: none;\r\n            background-color: #333;\r\n            color: #fff;\r\n            border-radius: 5px;\r\n            cursor: pointer;\r\n            transition: background-color 0.3s;\r\n        }\r\n\r\n        .form-container input[type=\"submit\"]:hover {\r\n            background-color: #555;\r\n        }\r\n\r\n        .form-container select {\r\n            padding: 10px;\r\n            margin-bottom: 15px;\r\n            border: 1px solid #ccc;\r\n            border-radius: 5px;\r\n            background-color: #ccc;\r\n        }\r\n\r\n        .password-container {\r\n            position: relative;\r\n            display: flex;\r\n            align-items: center;\r\n        }\r\n\r\n        .password-container input[type=\"password\"] {\r\n            padding-right: 40px; /* Espaço para o ícone */\r\n        }\r\n\r\n        .password-container img {\r\n            position: absolute;\r\n            right: 10px;\r\n            cursor: pointer;\r\n            width: 20px;\r\n            height: 20px;\r\n        }\r\n\r\n        .back-button {\r\n            position: absolute;\r\n            top: 10px;\r\n            left: 10px;\r\n            background-color: #f1f1f1;\r\n            border: none;\r\n            border-radius: 50%;\r\n            padding: 10px;\r\n            cursor: pointer;\r\n            box-shadow: 0 2px 4px rgba(0,0,0,0.1);\r\n            z-index: 1; /* Garantir que o botão fica acima dos outros elementos */\r\n        }\r\n\r\n        .back-button img {\r\n            width: 30px;\r\n            height: 30px;\r\n        }\r\n    </style>\r\n</head>\r\n\r\n<body>\r\n    <header class=\"cabecalho_principal\">\r\n        <!-- O conteúdo do cabeçalho -->\r\n    </header>\r\n    <div class=\"bnav_container\">\r\n        <div class=\"bnav_btn bnav_selected\">\r\n            <span>Clientes</span>\r\n        </div>\r\n        <div class=\"bnav_btn\" onclick=\"window.location.href=\'./listaproduto.php\'\">\r\n            <span>Produtos</span>\r\n        </div>\r\n    </div>\r\n    <main class=\"mainn form-container\">\r\n        <button class=\"back-button\" onclick=\"window.location.href=\'listacliente.php\'\">\r\n            <img src=\"../Icones/voltar.png\" alt=\"Voltar\">\r\n        </button>\r\n        <h2>Editar Cliente</h2>\r\n        <form method=\"POST\" action=\"\">\r\n            <label for=\"nome\">Nome:</label>\r\n            <input type=\"text\" id=\"nome\" name=\"nome\" value=\"<?php echo htmlspecialchars($user_data[\'nome\']); ?>\" required>\r\n\r\n            <label for=\"email\">Email:</label>\r\n            <input type=\"email\" id=\"email\" name=\"email\" value=\"<?php echo htmlspecialchars($user_data[\'email\']); ?>\" required>\r\n\r\n            <label for=\"senha\">Senha:</label>\r\n            <div class=\"password-container\">\r\n                <input type=\"password\" id=\"senha\" name=\"senha\" value=\"<?php echo htmlspecialchars($user_data[\'senha\']); ?>\" required>\r\n                <img src=\"../Icones/exibir.png\" id=\"togglePassword\" alt=\"Mostrar Senha\" onclick=\"togglePassword()\">\r\n            </div>\r\n\r\n            <label for=\"dt_nascimento\">Data de Nascimento:</label>\r\n            <input type=\"date\" id=\"dt_nascimento\" name=\"dt_nascimento\" value=\"<?php echo htmlspecialchars($user_data[\'dt_nascimento\']); ?>\" required>\r\n\r\n            <label for=\"ativo\">Ativo:</label>\r\n            <input type=\"checkbox\" id=\"ativo\" name=\"ativo\" <?php echo $user_data[\'ativo\'] ? \'checked\' : \'\'; ?>>\r\n\r\n            <label for=\"tipo\">Tipo:</label>\r\n            <select id=\"tipo\" name=\"tipo\">\r\n                <option value=\"cliente\" <?php echo $user_data[\'tipo\'] == \'cliente\' ? \'selected\' : \'\'; ?>>Cliente</option>\r\n                <option value=\"admin\" <?php echo $user_data[\'tipo\'] == \'admin\' ? \'selected\' : \'\'; ?>>Admin</option>\r\n            </select>\r\n\r\n            <input type=\"submit\" value=\"Atualizar\">\r\n        </form>\r\n        <?php if ($updateMessage) : ?>\r\n            <div id=\"updateMessage\" class=\"modal\">\r\n                <div class=\"modal-content\">\r\n                    <span class=\"modal-close\" onclick=\"document.getElementById(\'updateMessage\').style.display=\'none\'\">&times;</span>\r\n                    <p><?php echo $updateMessage; ?></p>\r\n                </div>\r\n            </div>\r\n            <script>\r\n                setTimeout(function() {\r\n                    document.getElementById(\'updateMessage\').style.display = \'none\';\r\n                }, 5000); // Ocultar a mensagem após 5 segundos\r\n            </script>\r\n        <?php endif; ?>\r\n    </main>\r\n\r\n    <script>\r\n        function togglePassword() {\r\n            var passwordField = document.getElementById(\'senha\');\r\n            var passwordIcon = document.getElementById(\'togglePassword\');\r\n            if (passwordField.type === \"password\") {\r\n                passwordField.type = \"text\";\r\n                passwordIcon.src = \"../Icones/ocultar.png\"; // Ícone de ocultar senha\r\n            } else {\r\n                passwordField.type = \"password\";\r\n                passwordIcon.src = \"../Icones/exibir.png\"; // Ícone de exibir senha\r\n            }\r\n        }\r\n    </script>\r\n</body>\r\n\r\n</html>\r\n', '2024-08-11 02:36:27'),
(14, 1, 'aaaaaaa', '2024-08-11 20:00:32');

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `tb_avaliacoes`
--
ALTER TABLE `tb_avaliacoes`
  ADD PRIMARY KEY (`id_avaliacao`);

--
-- Índices de tabela `tb_carrinho`
--
ALTER TABLE `tb_carrinho`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_usuario_id` (`usuario_id`),
  ADD KEY `fk_produto_id` (`produto_id`);

--
-- Índices de tabela `tb_categorias`
--
ALTER TABLE `tb_categorias`
  ADD PRIMARY KEY (`id_categoria`);

--
-- Índices de tabela `tb_clientes`
--
ALTER TABLE `tb_clientes`
  ADD PRIMARY KEY (`id_cliente`);

--
-- Índices de tabela `tb_contato`
--
ALTER TABLE `tb_contato`
  ADD PRIMARY KEY (`id_mensagem`);

--
-- Índices de tabela `tb_itens_compra`
--
ALTER TABLE `tb_itens_compra`
  ADD PRIMARY KEY (`id_item`),
  ADD KEY `id_pedido` (`id_compra`),
  ADD KEY `id_produto` (`id_produto`);

--
-- Índices de tabela `tb_pedidos`
--
ALTER TABLE `tb_pedidos`
  ADD PRIMARY KEY (`id_pedido`),
  ADD KEY `tb_cliente_fk` (`id_cliente`);

--
-- Índices de tabela `tb_produtos`
--
ALTER TABLE `tb_produtos`
  ADD PRIMARY KEY (`id_produto`),
  ADD KEY `id_categoria` (`id_categoria`);

--
-- Índices de tabela `tb_suporte`
--
ALTER TABLE `tb_suporte`
  ADD PRIMARY KEY (`id_suporte`),
  ADD KEY `id_cliente` (`id_cliente`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `tb_avaliacoes`
--
ALTER TABLE `tb_avaliacoes`
  MODIFY `id_avaliacao` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT de tabela `tb_carrinho`
--
ALTER TABLE `tb_carrinho`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `tb_categorias`
--
ALTER TABLE `tb_categorias`
  MODIFY `id_categoria` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT de tabela `tb_clientes`
--
ALTER TABLE `tb_clientes`
  MODIFY `id_cliente` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT de tabela `tb_contato`
--
ALTER TABLE `tb_contato`
  MODIFY `id_mensagem` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `tb_itens_compra`
--
ALTER TABLE `tb_itens_compra`
  MODIFY `id_item` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT de tabela `tb_pedidos`
--
ALTER TABLE `tb_pedidos`
  MODIFY `id_pedido` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT de tabela `tb_produtos`
--
ALTER TABLE `tb_produtos`
  MODIFY `id_produto` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT de tabela `tb_suporte`
--
ALTER TABLE `tb_suporte`
  MODIFY `id_suporte` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- Restrições para tabelas despejadas
--

--
-- Restrições para tabelas `tb_carrinho`
--
ALTER TABLE `tb_carrinho`
  ADD CONSTRAINT `fk_produto_id` FOREIGN KEY (`produto_id`) REFERENCES `tb_produtos` (`id_produto`),
  ADD CONSTRAINT `fk_usuario_id` FOREIGN KEY (`usuario_id`) REFERENCES `tb_clientes` (`id_cliente`);

--
-- Restrições para tabelas `tb_itens_compra`
--
ALTER TABLE `tb_itens_compra`
  ADD CONSTRAINT `tb_itens_compra_ibfk_1` FOREIGN KEY (`id_compra`) REFERENCES `tb_pedidos` (`id_pedido`),
  ADD CONSTRAINT `tb_itens_compra_ibfk_2` FOREIGN KEY (`id_produto`) REFERENCES `tb_produtos` (`id_produto`) ON DELETE CASCADE;

--
-- Restrições para tabelas `tb_pedidos`
--
ALTER TABLE `tb_pedidos`
  ADD CONSTRAINT `tb_cliente_fk` FOREIGN KEY (`id_cliente`) REFERENCES `tb_clientes` (`id_cliente`),
  ADD CONSTRAINT `tb_pedidos_ibfk_1` FOREIGN KEY (`id_cliente`) REFERENCES `tb_clientes` (`id_cliente`);

--
-- Restrições para tabelas `tb_produtos`
--
ALTER TABLE `tb_produtos`
  ADD CONSTRAINT `tb_produtos_ibfk_1` FOREIGN KEY (`id_categoria`) REFERENCES `tb_categorias` (`id_categoria`);

--
-- Restrições para tabelas `tb_suporte`
--
ALTER TABLE `tb_suporte`
  ADD CONSTRAINT `tb_suporte_ibfk_1` FOREIGN KEY (`id_cliente`) REFERENCES `tb_clientes` (`id_cliente`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
